public class Test4 {

	public static void main(String[] args) {		
		int x = 20;
		int y = 2;
        do {
            x=x+y;
           }while( x < 40 );	
	}	
}
