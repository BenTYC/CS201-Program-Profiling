public class Test3 {

	public static void main(String[] args) {		
		func1(100);	
		func2(10);	
	}
	
	public static void func1 (int x) {
	    int m=1
	    if (x == 0){
	    }
		while (x > 0) {
		    x=x-m;
		}
	}
	public static void func2 (int a) {
	    int n=1
	    if (a == 0){
	    }
		while (a < 100) {
		    a=a+n;
		}
	}
	
}
